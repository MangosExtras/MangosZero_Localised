UPDATE locales_creature set name_loc2='Waypoint',subname_loc2='GM Visual' where entry=1; -- Name: Waypoint -- subName: GM Visual
UPDATE locales_creature set name_loc2='Spawnpoint',subname_loc2='GM Visual' where entry=2; -- Name: Spawnpoint -- subName: GM Visual
UPDATE locales_creature set name_loc2='Karus',subname_loc2='Banker' where entry=3309; -- Name: Karus -- subName: Banker
UPDATE locales_creature set name_loc2='Koma',subname_loc2='Banker' where entry=3318; -- Name: Koma -- subName: Banker
UPDATE locales_creature set name_loc2='Soran',subname_loc2='Banker' where entry=3320; -- Name: Soran -- subName: Banker
UPDATE locales_creature set name_loc2='Cottontail Rabbit',subname_loc2='' where entry=7558; -- Name: Cottontail Rabbit
UPDATE locales_creature set name_loc2='Spotted Rabbit',subname_loc2='' where entry=7559; -- Name: Spotted Rabbit
UPDATE locales_creature set name_loc2='Auctioneer Thathung',subname_loc2='' where entry=8673; -- Name: Auctioneer Thathung
UPDATE locales_creature set name_loc2='Auctioneer Wabang',subname_loc2='' where entry=8724; -- Name: Auctioneer Wabang
UPDATE locales_creature set name_loc2='Auctioneer Grimful',subname_loc2='' where entry=9856; -- Name: Auctioneer Grimful
UPDATE locales_creature set name_loc2='Blue Qiraji Battle Tank',subname_loc2='' where entry=15713; -- Name: Blue Qiraji Battle Tank
