UPDATE locales_item set name_loc2='Black Metal Shortsword',description_loc2='' where entry=886; -- Name: Black Metal Shortsword
UPDATE locales_item set name_loc2='Lesser Firestone',description_loc2='' where entry=1254; -- Name: Lesser Firestone
UPDATE locales_item set name_loc2='Green Carapace Shield',description_loc2='' where entry=2021; -- Name: Green Carapace Shield
UPDATE locales_item set name_loc2='Small Brass Key',description_loc2='' where entry=2719; -- Name: Small Brass Key
UPDATE locales_item set name_loc2='Glyphed Breastplate',description_loc2='' where entry=3034; -- Name: Glyphed Breastplate
UPDATE locales_item set name_loc2='Work Shirt',description_loc2='' where entry=3148; -- Name: Work Shirt
UPDATE locales_item set name_loc2='Nightbane Staff',description_loc2='' where entry=3227; -- Name: Nightbane Staff
UPDATE locales_item set name_loc2='Dull Iron Key',description_loc2='' where entry=3467; -- Name: Dull Iron Key
UPDATE locales_item set name_loc2='Burnished Gold Key',description_loc2='' where entry=3499; -- Name: Burnished Gold Key
UPDATE locales_item set name_loc2='Rusted Iron Key',description_loc2='' where entry=3704; -- Name: Rusted Iron Key
UPDATE locales_item set name_loc2='Maury\'s Key',description_loc2='' where entry=3930; -- Name: Maury\'s Key
UPDATE locales_item set name_loc2='Benedict\'s Key',description_loc2='' where entry=4882; -- Name: Benedict\'s Key
UPDATE locales_item set name_loc2='Emberspark Pendant',description_loc2='' where entry=5005; -- Name: Emberspark Pendant
UPDATE locales_item set name_loc2='Explosive Shell',description_loc2='' where entry=5105; -- Name: Explosive Shell
UPDATE locales_item set name_loc2='Handstitched Leather Bracers',description_loc2='' where entry=5229; -- Name: Handstitched Leather Bracers
UPDATE locales_item set name_loc2='Key to Searing Gorge',description_loc2='' where entry=5396; -- Name: Key to Searing Gorge
UPDATE locales_item set name_loc2='Defias Gunpowder',description_loc2='' where entry=5397; -- Name: Defias Gunpowder
UPDATE locales_item set name_loc2='Tiny Bronze Key',description_loc2='A reagent for mage spells.' where entry=5517; -- Name: Tiny Bronze Key -- Description: A reagent for mage spells.
UPDATE locales_item set name_loc2='Tiny Iron Key',description_loc2='A reagent for mage spells.' where entry=5518; -- Name: Tiny Iron Key -- Description: A reagent for mage spells.
UPDATE locales_item set name_loc2='Spellstone',description_loc2='' where entry=5522; -- Name: Spellstone
UPDATE locales_item set name_loc2='Dim Torch',description_loc2='' where entry=6182; -- Name: Dim Torch
UPDATE locales_item set name_loc2='Unlit Poor Torch',description_loc2='' where entry=6183; -- Name: Unlit Poor Torch
UPDATE locales_item set name_loc2='15 Pound Mud Snapper',description_loc2='' where entry=6295; -- Name: 15 Pound Mud Snapper
UPDATE locales_item set name_loc2='Defias Tower Key',description_loc2='' where entry=7923; -- Name: Defias Tower Key
UPDATE locales_item set name_loc2='Silixiz\'s Tower Key',description_loc2='' where entry=8072; -- Name: Silixiz\'s Tower Key
UPDATE locales_item set name_loc2='Test Stationery',description_loc2='' where entry=8164; -- Name: Test Stationery
UPDATE locales_item set name_loc2='Reins of the Spotted Nightsaber',description_loc2='' where entry=8628; -- Name: Reins of the Spotted Nightsaber
UPDATE locales_item set name_loc2='Codex of Flash Heal',description_loc2='' where entry=8964; -- Name: Codex of Flash Heal
UPDATE locales_item set name_loc2='Thermaplugg\'s Safe Combination',description_loc2='' where entry=9299; -- Name: Thermaplugg\'s Safe Combination
UPDATE locales_item set name_loc2='Default Stationery',description_loc2='' where entry=9311; -- Name: Default Stationery
UPDATE locales_item set name_loc2='Gyromatic Icemaker',description_loc2='' where entry=9489; -- Name: Gyromatic Icemaker
UPDATE locales_item set name_loc2='Glyphic Rune',description_loc2='' where entry=9572; -- Name: Glyphic Rune
UPDATE locales_item set name_loc2='Hakkari Blood',description_loc2='' where entry=10460; -- Name: Hakkari Blood
UPDATE locales_item set name_loc2='Ward of the Defiler',description_loc2='The completed amulet of Rakh\'likh.' where entry=10757; -- Name: Ward of the Defiler -- Description: The completed amulet of Rakh\'likh.
UPDATE locales_item set name_loc2='Shadowforge Key',description_loc2='Master Key to the Depths, Courtesy of F.F.F.' where entry=11000; -- Name: Shadowforge Key -- Description: Master Key to the Depths, Courtesy of F.F.F.
UPDATE locales_item set name_loc2='Gor\'tesh\'s Lopped Off Head',description_loc2='Gor\'tesh\'s severed head, propped up on a pike.' where entry=11079; -- Name: Gor\'tesh\'s Lopped Off Head -- Description: Gor\'tesh\'s severed head, propped up on a pike.
UPDATE locales_item set name_loc2='Eggscilloscope',description_loc2='' where entry=12144; -- Name: Eggscilloscope
UPDATE locales_item set name_loc2='Bamboo Cage Key',description_loc2='' where entry=12301; -- Name: Bamboo Cage Key
UPDATE locales_item set name_loc2='The Judge\'s Gavel',description_loc2='' where entry=12400; -- Name: The Judge\'s Gavel
UPDATE locales_item set name_loc2='Alex\'s Ring of Audacity',description_loc2='' where entry=12947; -- Name: Alex\'s Ring of Audacity
UPDATE locales_item set name_loc2='Wand of Allistarj',description_loc2='' where entry=13065; -- Name: Wand of Allistarj
UPDATE locales_item set name_loc2='Market Row Postbox Key',description_loc2='' where entry=13302; -- Name: Market Row Postbox Key
UPDATE locales_item set name_loc2='Crusaders\' Square Postbox Key',description_loc2='' where entry=13303; -- Name: Crusaders\' Square Postbox Key
UPDATE locales_item set name_loc2='Festival Lane Postbox Key',description_loc2='' where entry=13304; -- Name: Festival Lane Postbox Key
UPDATE locales_item set name_loc2='Elders\' Square Postbox Key',description_loc2='' where entry=13305; -- Name: Elders\' Square Postbox Key
UPDATE locales_item set name_loc2='King\'s Square Postbox Key',description_loc2='' where entry=13306; -- Name: King\'s Square Postbox Key
UPDATE locales_item set name_loc2='Fras Siabi\'s Postbox Key',description_loc2='' where entry=13307; -- Name: Fras Siabi\'s Postbox Key
UPDATE locales_item set name_loc2='Greater Spellstone',description_loc2='' where entry=13602; -- Name: Greater Spellstone
UPDATE locales_item set name_loc2='Major Spellstone',description_loc2='' where entry=13603; -- Name: Major Spellstone
UPDATE locales_item set name_loc2='Firestone',description_loc2='' where entry=13699; -- Name: Firestone
UPDATE locales_item set name_loc2='Greater Firestone',description_loc2='' where entry=13700; -- Name: Greater Firestone
UPDATE locales_item set name_loc2='Major Firestone',description_loc2='' where entry=13701; -- Name: Major Firestone
UPDATE locales_item set name_loc2='Skeleton Key',description_loc2='' where entry=13704; -- Name: Skeleton Key
UPDATE locales_item set name_loc2='Viewing Room Key',description_loc2='' where entry=13873; -- Name: Viewing Room Key
UPDATE locales_item set name_loc2='Brightcloth Robe',description_loc2='' where entry=14100; -- Name: Brightcloth Robe
UPDATE locales_item set name_loc2='Brightcloth Pants',description_loc2='' where entry=14104; -- Name: Brightcloth Pants
UPDATE locales_item set name_loc2='Volcanic Leggings',description_loc2='' where entry=15054; -- Name: Volcanic Leggings
UPDATE locales_item set name_loc2='Frostsaber Tunic',description_loc2='' where entry=15068; -- Name: Frostsaber Tunic
UPDATE locales_item set name_loc2='Frostsaber Leggings',description_loc2='' where entry=15069; -- Name: Frostsaber Leggings
UPDATE locales_item set name_loc2='Frostsaber Gloves',description_loc2='' where entry=15070; -- Name: Frostsaber Gloves
UPDATE locales_item set name_loc2='Frostsaber Boots',description_loc2='' where entry=15071; -- Name: Frostsaber Boots
UPDATE locales_item set name_loc2='Chimeric Leggings',description_loc2='' where entry=15072; -- Name: Chimeric Leggings
UPDATE locales_item set name_loc2='Chimeric Gloves',description_loc2='' where entry=15074; -- Name: Chimeric Gloves
UPDATE locales_item set name_loc2='Chimeric Vest',description_loc2='' where entry=15075; -- Name: Chimeric Vest
UPDATE locales_item set name_loc2='Explorer\'s Knapsack',description_loc2='' where entry=16057; -- Name: Explorer\'s Knapsack
UPDATE locales_item set name_loc2='Test Arcane Res Legs Mail',description_loc2='' where entry=16165; -- Name: Test Arcane Res Legs Mail
UPDATE locales_item set name_loc2='Key to Salem\'s Chest',description_loc2='Opens Dark Cleric Salem\'s Chest' where entry=17242; -- Name: Key to Salem\'s Chest -- Description: Opens Dark Cleric Salem\'s Chest
UPDATE locales_item set name_loc2='James\' Key',description_loc2='Opens the stolen chest from the Cathedral of Light' where entry=17262; -- Name: James\' Key -- Description: Opens the stolen chest from the Cathedral of Light
UPDATE locales_item set name_loc2='Mulverick\'s Beacon',description_loc2='' where entry=17323; -- Name: Mulverick\'s Beacon
UPDATE locales_item set name_loc2='Jeztor\'s Beacon',description_loc2='' where entry=17325; -- Name: Jeztor\'s Beacon
UPDATE locales_item set name_loc2='Ryson\'s Beacon',description_loc2='' where entry=17362; -- Name: Ryson\'s Beacon
UPDATE locales_item set name_loc2='Ryson\'s Beacon',description_loc2='' where entry=17363; -- Name: Ryson\'s Beacon
UPDATE locales_item set name_loc2='Zinfizzlex\'s Portable Shredder Unit',description_loc2='' where entry=17384; -- Name: Zinfizzlex\'s Portable Shredder Unit
UPDATE locales_item set name_loc2='Zinfizzlex\'s Portable Shredder Unit',description_loc2='' where entry=17410; -- Name: Zinfizzlex\'s Portable Shredder Unit
UPDATE locales_item set name_loc2='Ichman\'s Beacon',description_loc2='' where entry=17505; -- Name: Ichman\'s Beacon
UPDATE locales_item set name_loc2='Vipore\'s Beacon',description_loc2='' where entry=17506; -- Name: Vipore\'s Beacon
UPDATE locales_item set name_loc2='Talisman of Binding Shard',description_loc2='' where entry=17782; -- Name: Talisman of Binding Shard
UPDATE locales_item set name_loc2='Tough Jerky',description_loc2='' where entry=18000; -- Name: Tough Jerky
UPDATE locales_item set name_loc2='Tough Hunk of Bread',description_loc2='' where entry=18001; -- Name: Tough Hunk of Bread
UPDATE locales_item set name_loc2='Refreshing Spring Water',description_loc2='' where entry=18005; -- Name: Refreshing Spring Water
UPDATE locales_item set name_loc2='Blizzard Stationery',description_loc2='' where entry=18154; -- Name: Blizzard Stationery
UPDATE locales_item set name_loc2='Gordok Courtyard Key',description_loc2='' where entry=18266; -- Name: Gordok Courtyard Key
UPDATE locales_item set name_loc2='Gordok Inner Door Key',description_loc2='' where entry=18268; -- Name: Gordok Inner Door Key
UPDATE locales_item set name_loc2='Vessel of Rebirth',description_loc2='' where entry=18565; -- Name: Vessel of Rebirth
UPDATE locales_item set name_loc2='Essence of the Firelord',description_loc2='' where entry=18566; -- Name: Essence of the Firelord
UPDATE locales_item set name_loc2='Ring of Critical Testing 2',description_loc2='' where entry=18970; -- Name: Ring of Critical Testing 2
UPDATE locales_item set name_loc2='Warsong Mark of Honor',description_loc2='Proof of winning a battle in Warsong Gulch' where entry=19322; -- Name: Warsong Mark of Honor -- Description: Proof of winning a battle in Warsong Gulch
UPDATE locales_item set name_loc2='Overlord\'s Embrace',description_loc2='' where entry=19760; -- Name: Overlord\'s Embrace
UPDATE locales_item set name_loc2='Alex\'s Test Beatdown Staff',description_loc2='' where entry=19879; -- Name: Alex\'s Test Beatdown Staff
UPDATE locales_item set name_loc2='Ooze-ridden Gauntlets',description_loc2='' where entry=21691; -- Name: Ooze-ridden Gauntlets
UPDATE locales_item set name_loc2='Scarab Coffer Key',description_loc2='' where entry=21761; -- Name: Scarab Coffer Key
UPDATE locales_item set name_loc2='Greater Scarab Coffer Key',description_loc2='' where entry=21762; -- Name: Greater Scarab Coffer Key
UPDATE locales_item set name_loc2='Valentine\'s Day Stationery',description_loc2='' where entry=22058; -- Name: Valentine\'s Day Stationery
UPDATE locales_item set name_loc2='Bindings of The Five Thunders',description_loc2='' where entry=22095; -- Name: Bindings of The Five Thunders
UPDATE locales_item set name_loc2='Boots of The Five Thunders',description_loc2='' where entry=22096; -- Name: Boots of The Five Thunders
UPDATE locales_item set name_loc2='Coif of The Five Thunders',description_loc2='' where entry=22097; -- Name: Coif of The Five Thunders
UPDATE locales_item set name_loc2='Cord of The Five Thunders',description_loc2='' where entry=22098; -- Name: Cord of The Five Thunders
UPDATE locales_item set name_loc2='Gauntlets of The Five Thunders',description_loc2='' where entry=22099; -- Name: Gauntlets of The Five Thunders
UPDATE locales_item set name_loc2='Kilt of The Five Thunders',description_loc2='' where entry=22100; -- Name: Kilt of The Five Thunders
UPDATE locales_item set name_loc2='Pauldrons of The Five Thunders',description_loc2='' where entry=22101; -- Name: Pauldrons of The Five Thunders
UPDATE locales_item set name_loc2='Vest of The Five Thunders',description_loc2='' where entry=22102; -- Name: Vest of The Five Thunders
UPDATE locales_item set name_loc2='Andonisus, Reaper of Souls',description_loc2='This blade is dimensional. It appears to be fading from this plane of existence.' where entry=22736; -- Name: Andonisus, Reaper of Souls -- Description: This blade is dimensional. It appears to be fading from this plane of existence.
UPDATE locales_item set name_loc2='Glaive of the Defender',description_loc2='' where entry=23051; -- Name: Glaive of the Defender
UPDATE locales_item set name_loc2='Diet McWeaksauce',description_loc2='Food for the Mind' where entry=23578; -- Name: Diet McWeaksauce -- Description: Food for the Mind
UPDATE locales_item set name_loc2='The McWeaksauce Classic',description_loc2='The Original.' where entry=23579; -- Name: The McWeaksauce Classic -- Description: The Original.
