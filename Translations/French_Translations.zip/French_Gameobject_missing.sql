UPDATE locales_gameobject set name_loc2='Eliza\'s Tombstone' where entry=37; -- Name: Eliza\'s Tombstone
UPDATE locales_gameobject set name_loc2='Captain Sanders Chest' where entry=38; -- Name: Captain Sanders Chest
UPDATE locales_gameobject set name_loc2='Mound of loose dirt' where entry=59; -- Name: Mound of loose dirt
UPDATE locales_gameobject set name_loc2='Abercrombie\'s Crate' where entry=167; -- Name: Abercrombie\'s Crate
UPDATE locales_gameobject set name_loc2='Crate of Foodstuffs' where entry=249; -- Name: Crate of Foodstuffs
UPDATE locales_gameobject set name_loc2='Research Equipment' where entry=251; -- Name: Research Equipment
UPDATE locales_gameobject set name_loc2='Wanted: Chok\'Sul' where entry=254; -- Name: Wanted: Chok\'Sul
UPDATE locales_gameobject set name_loc2='Water Pitcher' where entry=337; -- Name: Water Pitcher
UPDATE locales_gameobject set name_loc2='Wanted!' where entry=711; -- Name: Wanted!
UPDATE locales_gameobject set name_loc2='Corpse Laden Boat' where entry=1593; -- Name: Corpse Laden Boat
UPDATE locales_gameobject set name_loc2='Shallow Grave' where entry=1599; -- Name: Shallow Grave
UPDATE locales_gameobject set name_loc2='Agamand Mills' where entry=1631; -- Name: Agamand Mills
UPDATE locales_gameobject set name_loc2='Brill' where entry=1632; -- Name: Brill
UPDATE locales_gameobject set name_loc2='Deathknell' where entry=1638; -- Name: Deathknell
UPDATE locales_gameobject set name_loc2='Stanley\'s Dish' where entry=1720; -- Name: Stanley\'s Dish
UPDATE locales_gameobject set name_loc2='Syndicate Documents' where entry=1738; -- Name: Syndicate Documents
UPDATE locales_gameobject set name_loc2='Syndicate Documents' where entry=1739; -- Name: Syndicate Documents
UPDATE locales_gameobject set name_loc2='Anvil' where entry=1752; -- Name: Anvil
UPDATE locales_gameobject set name_loc2='Forge' where entry=1753; -- Name: Forge
UPDATE locales_gameobject set name_loc2='Anvil' where entry=1754; -- Name: Anvil
UPDATE locales_gameobject set name_loc2='Forge' where entry=1755; -- Name: Forge
UPDATE locales_gameobject set name_loc2='WANTED' where entry=1763; -- Name: WANTED
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1798; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1803; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1818; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1821; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1828; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1830; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1871; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1888; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1889; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1890; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Forge' where entry=1896; -- Name: Forge
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1905; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1906; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1912; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1922; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1927; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1930; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1931; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1932; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1935; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1938; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1942; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1965; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1968; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1993; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1994; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1995; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=1996; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=2003; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Smoldering Fire' where entry=2004; -- Name: Smoldering Fire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=2007; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Dangerous!' where entry=2008; -- Name: Dangerous!
UPDATE locales_gameobject set name_loc2='Deathknell' where entry=2035; -- Name: Deathknell
UPDATE locales_gameobject set name_loc2='The Wine Cask' where entry=2130; -- Name: The Wine Cask
UPDATE locales_gameobject set name_loc2='The Cheese Cutters' where entry=2148; -- Name: The Cheese Cutters
UPDATE locales_gameobject set name_loc2='The Seven Deadly Venoms' where entry=2149; -- Name: The Seven Deadly Venoms
UPDATE locales_gameobject set name_loc2='Thane\'s Boots and Shoulderpads' where entry=2151; -- Name: Thane\'s Boots and Shoulderpads
UPDATE locales_gameobject set name_loc2='Mage Quarters' where entry=2188; -- Name: Mage Quarters
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=2413; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Need Name' where entry=2414; -- Name: Need Name
UPDATE locales_gameobject set name_loc2='Anvil' where entry=2572; -- Name: Anvil
UPDATE locales_gameobject set name_loc2='Forge' where entry=2573; -- Name: Forge
UPDATE locales_gameobject set name_loc2='Anvil' where entry=2649; -- Name: Anvil
UPDATE locales_gameobject set name_loc2='Forge' where entry=2650; -- Name: Forge
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=2658; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Pillar of Diamond' where entry=2842; -- Name: Pillar of Diamond
UPDATE locales_gameobject set name_loc2='Pillar of Opal' where entry=2848; -- Name: Pillar of Opal
UPDATE locales_gameobject set name_loc2='Pillar of Amethyst' where entry=2858; -- Name: Pillar of Amethyst
UPDATE locales_gameobject set name_loc2='Seal of the Earth' where entry=2933; -- Name: Seal of the Earth
UPDATE locales_gameobject set name_loc2='Campfire' where entry=3085; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=3089; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Razor Hill' where entry=3224; -- Name: Razor Hill
UPDATE locales_gameobject set name_loc2='Benedict\'s Chest' where entry=3239; -- Name: Benedict\'s Chest
UPDATE locales_gameobject set name_loc2='Campfire' where entry=3253; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=3254; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=3270; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=3306; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=3638; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=3639; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=3760; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=3761; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Drizzlik\'s Emporium' where entry=3767; -- Name: Drizzlik\'s Emporium
UPDATE locales_gameobject set name_loc2='Fragile - Do Not Drop' where entry=3768; -- Name: Fragile - Do Not Drop
UPDATE locales_gameobject set name_loc2='Fire Plume Ridge Lava Lake' where entry=4004; -- Name: Fire Plume Ridge Lava Lake
UPDATE locales_gameobject set name_loc2='Bank' where entry=4005; -- Name: Bank
UPDATE locales_gameobject set name_loc2='The Crossroads' where entry=4102; -- Name: The Crossroads
UPDATE locales_gameobject set name_loc2='Stonetalon Mountains' where entry=4103; -- Name: Stonetalon Mountains
UPDATE locales_gameobject set name_loc2='Campfire' where entry=6293; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=6294; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=6295; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Red Raptor Nest' where entry=6906; -- Name: Red Raptor Nest
UPDATE locales_gameobject set name_loc2='Blue Raptor Nest' where entry=6907; -- Name: Blue Raptor Nest
UPDATE locales_gameobject set name_loc2='Yellow Raptor Nest' where entry=6908; -- Name: Yellow Raptor Nest
UPDATE locales_gameobject set name_loc2='Cooking Fire' where entry=9847; -- Name: Cooking Fire
UPDATE locales_gameobject set name_loc2='Cooking Fire' where entry=10388; -- Name: Cooking Fire
UPDATE locales_gameobject set name_loc2='Twilight Tome' where entry=12144; -- Name: Twilight Tome
UPDATE locales_gameobject set name_loc2='Cat Figurine Trap' where entry=12653; -- Name: Cat Figurine Trap
UPDATE locales_gameobject set name_loc2='Twilight Tome' where entry=12666; -- Name: Twilight Tome
UPDATE locales_gameobject set name_loc2='Graveyard Banner' where entry=13756; -- Name: Graveyard Banner
UPDATE locales_gameobject set name_loc2='Target' where entry=13952; -- Name: Target
UPDATE locales_gameobject set name_loc2='Mine Banner' where entry=15001; -- Name: Mine Banner
UPDATE locales_gameobject set name_loc2='Lumber Mill Banner' where entry=15002; -- Name: Lumber Mill Banner
UPDATE locales_gameobject set name_loc2='Farm Banner' where entry=15003; -- Name: Farm Banner
UPDATE locales_gameobject set name_loc2='Blacksmith Banner' where entry=15004; -- Name: Blacksmith Banner
UPDATE locales_gameobject set name_loc2='Stable Banner' where entry=15005; -- Name: Stable Banner
UPDATE locales_gameobject set name_loc2='Cracked Necrotic Crystal' where entry=16431; -- Name: Cracked Necrotic Crystal
UPDATE locales_gameobject set name_loc2='Buzzbox 323' where entry=17184; -- Name: Buzzbox 323
UPDATE locales_gameobject set name_loc2='The Lay of Ameth\'Aran' where entry=17188; -- Name: The Lay of Ameth\'Aran
UPDATE locales_gameobject set name_loc2='The Fall of Ameth\'Aran' where entry=17189; -- Name: The Fall of Ameth\'Aran
UPDATE locales_gameobject set name_loc2='Campfire' where entry=18046; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Bubbling Cauldron' where entry=18084; -- Name: Bubbling Cauldron
UPDATE locales_gameobject set name_loc2='Campfire' where entry=18085; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=18087; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Cliffspring Falls Cave Mouth' where entry=19463; -- Name: Cliffspring Falls Cave Mouth
UPDATE locales_gameobject set name_loc2='Dreadmist Peak Pool' where entry=19464; -- Name: Dreadmist Peak Pool
UPDATE locales_gameobject set name_loc2='Crackling Campfire' where entry=19536; -- Name: Crackling Campfire
UPDATE locales_gameobject set name_loc2='The Charred Vale' where entry=19577; -- Name: The Charred Vale
UPDATE locales_gameobject set name_loc2='Goblin Shredder Suit' where entry=19582; -- Name: Goblin Shredder Suit
UPDATE locales_gameobject set name_loc2='Freewind Post' where entry=19848; -- Name: Freewind Post
UPDATE locales_gameobject set name_loc2='The Shimmering Flats' where entry=19849; -- Name: The Shimmering Flats
UPDATE locales_gameobject set name_loc2='Tanaris' where entry=19850; -- Name: Tanaris
UPDATE locales_gameobject set name_loc2='The Great Lift' where entry=19851; -- Name: The Great Lift
UPDATE locales_gameobject set name_loc2='The Barrens' where entry=19852; -- Name: The Barrens
UPDATE locales_gameobject set name_loc2='Freewind Post' where entry=19853; -- Name: Freewind Post
UPDATE locales_gameobject set name_loc2='The Barrens' where entry=19854; -- Name: The Barrens
UPDATE locales_gameobject set name_loc2='Tanaris' where entry=19855; -- Name: Tanaris
UPDATE locales_gameobject set name_loc2='The Barrens' where entry=19856; -- Name: The Barrens
UPDATE locales_gameobject set name_loc2='The Shimmering Flats' where entry=19857; -- Name: The Shimmering Flats
UPDATE locales_gameobject set name_loc2='Thalanaar' where entry=19858; -- Name: Thalanaar
UPDATE locales_gameobject set name_loc2='Feralas' where entry=19859; -- Name: Feralas
UPDATE locales_gameobject set name_loc2='Circle of Imprisonment' where entry=19901; -- Name: Circle of Imprisonment
UPDATE locales_gameobject set name_loc2='Forge' where entry=19902; -- Name: Forge
UPDATE locales_gameobject set name_loc2='Circle of Imprisonment' where entry=20352; -- Name: Circle of Imprisonment
UPDATE locales_gameobject set name_loc2='Campfire' where entry=20356; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Mine' where entry=20811; -- Name: Mine
UPDATE locales_gameobject set name_loc2='Orc Tower' where entry=20812; -- Name: Orc Tower
UPDATE locales_gameobject set name_loc2='Guard Tower' where entry=20816; -- Name: Guard Tower
UPDATE locales_gameobject set name_loc2='Holding Pen' where entry=20817; -- Name: Holding Pen
UPDATE locales_gameobject set name_loc2='Night Elf Moon Well' where entry=20818; -- Name: Night Elf Moon Well
UPDATE locales_gameobject set name_loc2='Moon Well 2' where entry=20819; -- Name: Moon Well 2
UPDATE locales_gameobject set name_loc2='Giant Sea Turtle' where entry=20820; -- Name: Giant Sea Turtle
UPDATE locales_gameobject set name_loc2='Giant Turtle' where entry=20821; -- Name: Giant Turtle
UPDATE locales_gameobject set name_loc2='Landing Pad' where entry=20822; -- Name: Landing Pad
UPDATE locales_gameobject set name_loc2='Player Housing' where entry=20823; -- Name: Player Housing
UPDATE locales_gameobject set name_loc2='Orc Tower' where entry=20824; -- Name: Orc Tower
UPDATE locales_gameobject set name_loc2='Stormwind City' where entry=20827; -- Name: Stormwind City
UPDATE locales_gameobject set name_loc2='Crackling Campfire' where entry=20850; -- Name: Crackling Campfire
UPDATE locales_gameobject set name_loc2='Smoldering Brazier' where entry=20873; -- Name: Smoldering Brazier
UPDATE locales_gameobject set name_loc2='Smoldering Brazier' where entry=20874; -- Name: Smoldering Brazier
UPDATE locales_gameobject set name_loc2='Smoldering Brazier' where entry=20875; -- Name: Smoldering Brazier
UPDATE locales_gameobject set name_loc2='Smoldering Brazier' where entry=20876; -- Name: Smoldering Brazier
UPDATE locales_gameobject set name_loc2='Cauldron' where entry=20878; -- Name: Cauldron
UPDATE locales_gameobject set name_loc2='Crackling Campfire' where entry=20879; -- Name: Crackling Campfire
UPDATE locales_gameobject set name_loc2='Flickering Campfire' where entry=20881; -- Name: Flickering Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=20924; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Flickering Campfire' where entry=20926; -- Name: Flickering Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=20972; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=20983; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Hoofprints' where entry=21015; -- Name: Hoofprints
UPDATE locales_gameobject set name_loc2='Hoofprints' where entry=21016; -- Name: Hoofprints
UPDATE locales_gameobject set name_loc2='Campfire' where entry=21282; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Lashh\'an Spell Circle' where entry=21511; -- Name: Lashh\'an Spell Circle
UPDATE locales_gameobject set name_loc2='Anvil' where entry=21628; -- Name: Anvil
UPDATE locales_gameobject set name_loc2='Anvil' where entry=21629; -- Name: Anvil
UPDATE locales_gameobject set name_loc2='Forge' where entry=21630; -- Name: Forge
UPDATE locales_gameobject set name_loc2='Forge' where entry=21631; -- Name: Forge
UPDATE locales_gameobject set name_loc2='unk' where entry=21653; -- Name: unk
UPDATE locales_gameobject set name_loc2='unk' where entry=21654; -- Name: unk
UPDATE locales_gameobject set name_loc2='unk' where entry=21655; -- Name: unk
UPDATE locales_gameobject set name_loc2='unk' where entry=21656; -- Name: unk
UPDATE locales_gameobject set name_loc2='Dwarven Fire' where entry=22205; -- Name: Dwarven Fire
UPDATE locales_gameobject set name_loc2='Dwarven Fire' where entry=22207; -- Name: Dwarven Fire
UPDATE locales_gameobject set name_loc2='Dwarven Fire' where entry=22208; -- Name: Dwarven Fire
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=22249; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Desk Chair' where entry=22256; -- Name: Desk Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=22542; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=22618; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=22663; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=22796; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=22797; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=22798; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=22799; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='High Back Chair' where entry=22800; -- Name: High Back Chair
UPDATE locales_gameobject set name_loc2='High Back Chair' where entry=22801; -- Name: High Back Chair
UPDATE locales_gameobject set name_loc2='High Back Chair' where entry=22802; -- Name: High Back Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=22808; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=22809; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=22810; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=22816; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=22817; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Gizmorium Shipping Crate' where entry=23505; -- Name: Gizmorium Shipping Crate
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=23880; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=23881; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Stone Bench' where entry=24397; -- Name: Stone Bench
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=24493; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=24500; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=24501; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=24502; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=24503; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=24504; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=24505; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=24510; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=24511; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Industrial District' where entry=25334; -- Name: Industrial District
UPDATE locales_gameobject set name_loc2='The Park' where entry=25342; -- Name: The Park
UPDATE locales_gameobject set name_loc2='The Park' where entry=25352; -- Name: The Park
UPDATE locales_gameobject set name_loc2='Cathedral Square' where entry=25355; -- Name: Cathedral Square
UPDATE locales_gameobject set name_loc2='Cathedral Square' where entry=25356; -- Name: Cathedral Square
UPDATE locales_gameobject set name_loc2='Cathedral Square' where entry=25357; -- Name: Cathedral Square
UPDATE locales_gameobject set name_loc2='Craghelm\'s Plate and Chain' where entry=26480; -- Name: Craghelm\'s Plate and Chain
UPDATE locales_gameobject set name_loc2='Goldfury\'s Hunting Supplies' where entry=26482; -- Name: Goldfury\'s Hunting Supplies
UPDATE locales_gameobject set name_loc2='Fizzlespinner\'s General Goods' where entry=26483; -- Name: Fizzlespinner\'s General Goods
UPDATE locales_gameobject set name_loc2='Thundershot Guns \'n Ammo' where entry=26485; -- Name: Thundershot Guns \'n Ammo
UPDATE locales_gameobject set name_loc2='The Stonefire Tavern' where entry=26486; -- Name: The Stonefire Tavern
UPDATE locales_gameobject set name_loc2='Barim\'s Reagents' where entry=26487; -- Name: Barim\'s Reagents
UPDATE locales_gameobject set name_loc2='Timberline Arms' where entry=26488; -- Name: Timberline Arms
UPDATE locales_gameobject set name_loc2='Bruuk\'s Corner' where entry=26489; -- Name: Bruuk\'s Corner
UPDATE locales_gameobject set name_loc2='Ironforge Visitor\'s Center' where entry=26490; -- Name: Ironforge Visitor\'s Center
UPDATE locales_gameobject set name_loc2='Pithwick\'s Bags and Supplies' where entry=26491; -- Name: Pithwick\'s Bags and Supplies
UPDATE locales_gameobject set name_loc2='Farmountain Maps' where entry=26492; -- Name: Farmountain Maps
UPDATE locales_gameobject set name_loc2='Stonebranch Herbalist' where entry=26493; -- Name: Stonebranch Herbalist
UPDATE locales_gameobject set name_loc2='Deep Mountain Mining Guild' where entry=26497; -- Name: Deep Mountain Mining Guild
UPDATE locales_gameobject set name_loc2='The Bronze Kettle' where entry=26498; -- Name: The Bronze Kettle
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=28048; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=28049; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=28050; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=28051; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=28052; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=28053; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=28054; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=28055; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=28056; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=28605; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=28606; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=28607; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=28608; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=28609; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=28610; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Dwarven High Back Chair' where entry=28611; -- Name: Dwarven High Back Chair
UPDATE locales_gameobject set name_loc2='Dwarven High Back Chair' where entry=28612; -- Name: Dwarven High Back Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=28613; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Medium Brazier' where entry=31576; -- Name: Medium Brazier
UPDATE locales_gameobject set name_loc2='IronForge Elevator' where entry=32056; -- Name: IronForge Elevator
UPDATE locales_gameobject set name_loc2='IronForge Elevator' where entry=32057; -- Name: IronForge Elevator
UPDATE locales_gameobject set name_loc2='Roaring Fire' where entry=32109; -- Name: Roaring Fire
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=32110; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Flinthammer\'s Armorer and Clothier' where entry=32348; -- Name: Flinthammer\'s Armorer and Clothier
UPDATE locales_gameobject set name_loc2='Finespindle\'s Leather Goods' where entry=32350; -- Name: Finespindle\'s Leather Goods
UPDATE locales_gameobject set name_loc2='Stonebrow\'s Clothier' where entry=32351; -- Name: Stonebrow\'s Clothier
UPDATE locales_gameobject set name_loc2='Traveling Fisherman' where entry=32352; -- Name: Traveling Fisherman
UPDATE locales_gameobject set name_loc2='Springspindle\'s Gadgets' where entry=32353; -- Name: Springspindle\'s Gadgets
UPDATE locales_gameobject set name_loc2='Things That Go Boom!' where entry=32354; -- Name: Things That Go Boom!
UPDATE locales_gameobject set name_loc2='Hall of Explorers' where entry=32356; -- Name: Hall of Explorers
UPDATE locales_gameobject set name_loc2='The Commerce Ward' where entry=32357; -- Name: The Commerce Ward
UPDATE locales_gameobject set name_loc2='The Military Ward' where entry=32359; -- Name: The Military Ward
UPDATE locales_gameobject set name_loc2='Hall of Explorers' where entry=32360; -- Name: Hall of Explorers
UPDATE locales_gameobject set name_loc2='The Commerce Ward' where entry=32361; -- Name: The Commerce Ward
UPDATE locales_gameobject set name_loc2='The Mystic Ward' where entry=32362; -- Name: The Mystic Ward
UPDATE locales_gameobject set name_loc2='Hall of Explorers' where entry=32363; -- Name: Hall of Explorers
UPDATE locales_gameobject set name_loc2='Market Walk' where entry=32364; -- Name: Market Walk
UPDATE locales_gameobject set name_loc2='The Military Ward' where entry=32365; -- Name: The Military Ward
UPDATE locales_gameobject set name_loc2='Market Walk' where entry=32366; -- Name: Market Walk
UPDATE locales_gameobject set name_loc2='Ironforge Main Gate' where entry=32367; -- Name: Ironforge Main Gate
UPDATE locales_gameobject set name_loc2='Market Walk' where entry=32368; -- Name: Market Walk
UPDATE locales_gameobject set name_loc2='Ironforge Main Gate' where entry=32370; -- Name: Ironforge Main Gate
UPDATE locales_gameobject set name_loc2='Hall of Explorers' where entry=32371; -- Name: Hall of Explorers
UPDATE locales_gameobject set name_loc2='The Great Forge' where entry=32372; -- Name: The Great Forge
UPDATE locales_gameobject set name_loc2='The Great Forge' where entry=32373; -- Name: The Great Forge
UPDATE locales_gameobject set name_loc2='The Great Forge' where entry=32374; -- Name: The Great Forge
UPDATE locales_gameobject set name_loc2='The Great Forge' where entry=32375; -- Name: The Great Forge
UPDATE locales_gameobject set name_loc2='Market Walk' where entry=32376; -- Name: Market Walk
UPDATE locales_gameobject set name_loc2='Vault of Ironforge' where entry=32377; -- Name: Vault of Ironforge
UPDATE locales_gameobject set name_loc2='The Great Forge' where entry=32378; -- Name: The Great Forge
UPDATE locales_gameobject set name_loc2='The Great Forge' where entry=32379; -- Name: The Great Forge
UPDATE locales_gameobject set name_loc2='Vault of Ironforge' where entry=32380; -- Name: Vault of Ironforge
UPDATE locales_gameobject set name_loc2='The Forlorn Caverns' where entry=32381; -- Name: The Forlorn Caverns
UPDATE locales_gameobject set name_loc2='Market Walk' where entry=32384; -- Name: Market Walk
UPDATE locales_gameobject set name_loc2='Hall of Mysteries' where entry=32386; -- Name: Hall of Mysteries
UPDATE locales_gameobject set name_loc2='Market Walk' where entry=32388; -- Name: Market Walk
UPDATE locales_gameobject set name_loc2='Hall of Arms' where entry=32390; -- Name: Hall of Arms
UPDATE locales_gameobject set name_loc2='The Great Forge' where entry=32392; -- Name: The Great Forge
UPDATE locales_gameobject set name_loc2='Market Walk' where entry=32393; -- Name: Market Walk
UPDATE locales_gameobject set name_loc2='Market Walk' where entry=32394; -- Name: Market Walk
UPDATE locales_gameobject set name_loc2='The Great Forge' where entry=32395; -- Name: The Great Forge
UPDATE locales_gameobject set name_loc2='Ironforge Main Gate' where entry=32396; -- Name: Ironforge Main Gate
UPDATE locales_gameobject set name_loc2='Ironforge Main Gate' where entry=32397; -- Name: Ironforge Main Gate
UPDATE locales_gameobject set name_loc2='Ironforge Main Gate' where entry=32398; -- Name: Ironforge Main Gate
UPDATE locales_gameobject set name_loc2='Ironforge Main Gate' where entry=32399; -- Name: Ironforge Main Gate
UPDATE locales_gameobject set name_loc2='The Commerce Ward' where entry=32400; -- Name: The Commerce Ward
UPDATE locales_gameobject set name_loc2='The Commerce Ward' where entry=32401; -- Name: The Commerce Ward
UPDATE locales_gameobject set name_loc2='Ironforge Main Gate' where entry=32402; -- Name: Ironforge Main Gate
UPDATE locales_gameobject set name_loc2='The Commerce Ward' where entry=32403; -- Name: The Commerce Ward
UPDATE locales_gameobject set name_loc2='Ironforge Main Gate' where entry=32405; -- Name: Ironforge Main Gate
UPDATE locales_gameobject set name_loc2='Market Walk' where entry=32406; -- Name: Market Walk
UPDATE locales_gameobject set name_loc2='Market Walk' where entry=32407; -- Name: Market Walk
UPDATE locales_gameobject set name_loc2='Hall of Explorers' where entry=32408; -- Name: Hall of Explorers
UPDATE locales_gameobject set name_loc2='The Commerce Ward' where entry=32409; -- Name: The Commerce Ward
UPDATE locales_gameobject set name_loc2='Ironforge Main Gate' where entry=32410; -- Name: Ironforge Main Gate
UPDATE locales_gameobject set name_loc2='Ironforge Main Gate' where entry=32411; -- Name: Ironforge Main Gate
UPDATE locales_gameobject set name_loc2='Market Walk' where entry=32412; -- Name: Market Walk
UPDATE locales_gameobject set name_loc2='Hall of Explorers' where entry=32413; -- Name: Hall of Explorers
UPDATE locales_gameobject set name_loc2='The Commerce Ward' where entry=32414; -- Name: The Commerce Ward
UPDATE locales_gameobject set name_loc2='The Commerce Ward' where entry=32417; -- Name: The Commerce Ward
UPDATE locales_gameobject set name_loc2='Hall of Explorers' where entry=32418; -- Name: Hall of Explorers
UPDATE locales_gameobject set name_loc2='Gnomes' where entry=32419; -- Name: Gnomes
UPDATE locales_gameobject set name_loc2='The Commerce Ward' where entry=32420; -- Name: The Commerce Ward
UPDATE locales_gameobject set name_loc2='Hall of Explorers' where entry=32421; -- Name: Hall of Explorers
UPDATE locales_gameobject set name_loc2='Hall of Explorers' where entry=32423; -- Name: Hall of Explorers
UPDATE locales_gameobject set name_loc2='The Military Ward' where entry=32428; -- Name: The Military Ward
UPDATE locales_gameobject set name_loc2='Ironforge Main Gate' where entry=32430; -- Name: Ironforge Main Gate
UPDATE locales_gameobject set name_loc2='The Military Ward' where entry=32434; -- Name: The Military Ward
UPDATE locales_gameobject set name_loc2='The Great Forge' where entry=32436; -- Name: The Great Forge
UPDATE locales_gameobject set name_loc2='The Mystic Ward' where entry=32438; -- Name: The Mystic Ward
UPDATE locales_gameobject set name_loc2='Ironforge Main Gate' where entry=32440; -- Name: Ironforge Main Gate
UPDATE locales_gameobject set name_loc2='Anvil' where entry=32595; -- Name: Anvil
UPDATE locales_gameobject set name_loc2='Market Walk' where entry=32783; -- Name: Market Walk
UPDATE locales_gameobject set name_loc2='Market Walk' where entry=32784; -- Name: Market Walk
UPDATE locales_gameobject set name_loc2='Market Walk' where entry=32785; -- Name: Market Walk
UPDATE locales_gameobject set name_loc2='Hall of Explorers' where entry=32786; -- Name: Hall of Explorers
UPDATE locales_gameobject set name_loc2='Market Walk' where entry=32787; -- Name: Market Walk
UPDATE locales_gameobject set name_loc2='Hall of Explorers' where entry=32788; -- Name: Hall of Explorers
UPDATE locales_gameobject set name_loc2='The Great Forge' where entry=32789; -- Name: The Great Forge
UPDATE locales_gameobject set name_loc2='The Great Forge' where entry=32790; -- Name: The Great Forge
UPDATE locales_gameobject set name_loc2='The Mystic Ward' where entry=32791; -- Name: The Mystic Ward
UPDATE locales_gameobject set name_loc2='Market Walk' where entry=32792; -- Name: Market Walk
UPDATE locales_gameobject set name_loc2='Hall of Explorers' where entry=32793; -- Name: Hall of Explorers
UPDATE locales_gameobject set name_loc2='BerryFizz Potions and Mixed Drinks' where entry=34357; -- Name: BerryFizz Potions and Mixed Drinks
UPDATE locales_gameobject set name_loc2='The Forlorn Cavern' where entry=34358; -- Name: The Forlorn Cavern
UPDATE locales_gameobject set name_loc2='The Forlorn Cavern' where entry=34359; -- Name: The Forlorn Cavern
UPDATE locales_gameobject set name_loc2='The Forlorn Cavern' where entry=34361; -- Name: The Forlorn Cavern
UPDATE locales_gameobject set name_loc2='The Forlorn Cavern' where entry=34362; -- Name: The Forlorn Cavern
UPDATE locales_gameobject set name_loc2='The Forlorn Cavern' where entry=34363; -- Name: The Forlorn Cavern
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=35572; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=35573; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=35574; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=35575; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=35576; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Dwarven High Back Chair' where entry=35577; -- Name: Dwarven High Back Chair
UPDATE locales_gameobject set name_loc2='Dwarven High Back Chair' where entry=35578; -- Name: Dwarven High Back Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=35579; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Dwarven High Back Chair' where entry=35580; -- Name: Dwarven High Back Chair
UPDATE locales_gameobject set name_loc2='Dwarven High Back Chair' where entry=35581; -- Name: Dwarven High Back Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=35582; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=35583; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=35584; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=35585; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Dwarven High Back Chair' where entry=35588; -- Name: Dwarven High Back Chair
UPDATE locales_gameobject set name_loc2='Dwarven High Back Chair' where entry=35589; -- Name: Dwarven High Back Chair
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=36645; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Dining Bench' where entry=36990; -- Name: Dining Bench
UPDATE locales_gameobject set name_loc2='Dining Bench' where entry=36991; -- Name: Dining Bench
UPDATE locales_gameobject set name_loc2='Dining Bench' where entry=36992; -- Name: Dining Bench
UPDATE locales_gameobject set name_loc2='Dining Bench' where entry=36993; -- Name: Dining Bench
UPDATE locales_gameobject set name_loc2='Dining Bench' where entry=36994; -- Name: Dining Bench
UPDATE locales_gameobject set name_loc2='Dining Bench' where entry=36995; -- Name: Dining Bench
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=37473; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Dwarven High Back Chair' where entry=37474; -- Name: Dwarven High Back Chair
UPDATE locales_gameobject set name_loc2='Dwarven High Back Chair' where entry=37475; -- Name: Dwarven High Back Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=37476; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=37477; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=37479; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Dwarven High Back Chair' where entry=37480; -- Name: Dwarven High Back Chair
UPDATE locales_gameobject set name_loc2='Dwarven High Back Chair' where entry=37481; -- Name: Dwarven High Back Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=37482; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Dwarven High Back Chair' where entry=37483; -- Name: Dwarven High Back Chair
UPDATE locales_gameobject set name_loc2='Dwarven High Back Chair' where entry=37484; -- Name: Dwarven High Back Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=37485; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=37486; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=37487; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=37488; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=37489; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=37490; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=37491; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Dwarven High Back Chair' where entry=37492; -- Name: Dwarven High Back Chair
UPDATE locales_gameobject set name_loc2='Dwarven High Back Chair' where entry=37493; -- Name: Dwarven High Back Chair
UPDATE locales_gameobject set name_loc2='Cookpot' where entry=38019; -- Name: Cookpot
UPDATE locales_gameobject set name_loc2='Potbelly Stove' where entry=38020; -- Name: Potbelly Stove
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=38021; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=38022; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=38023; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Dwarven High Back Chair' where entry=38024; -- Name: Dwarven High Back Chair
UPDATE locales_gameobject set name_loc2='Dwarven High Back Chair' where entry=38025; -- Name: Dwarven High Back Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=38026; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=38027; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Fire' where entry=40198; -- Name: Fire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=40299; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=55616; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=56820; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=57709; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=57710; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=57725; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=57726; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=57727; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=57748; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=57749; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=57750; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=57751; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=57752; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=57753; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Cauldron' where entry=59529; -- Name: Cauldron
UPDATE locales_gameobject set name_loc2='Cauldron' where entry=59530; -- Name: Cauldron
UPDATE locales_gameobject set name_loc2='Campfire' where entry=60394; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=61927; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=61928; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=61952; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Brazier' where entry=61953; -- Name: Brazier
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=64849; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=64850; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Fire Totem' where entry=67234; -- Name: Fire Totem
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=69425; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=69431; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70518; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70519; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70520; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70521; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70522; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70523; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70524; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70525; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70526; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70527; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70528; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70530; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70531; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70532; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70533; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70534; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70535; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70536; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70537; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70538; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70539; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70540; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70541; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70542; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70543; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70544; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70545; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70546; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70547; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70548; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70549; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70551; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70552; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70553; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70554; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70555; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70556; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=70557; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Cauldron' where entry=74077; -- Name: Cauldron
UPDATE locales_gameobject set name_loc2='Smoked Meat Rack' where entry=74446; -- Name: Smoked Meat Rack
UPDATE locales_gameobject set name_loc2='Noggle\'s Satchel' where entry=74731; -- Name: Noggle\'s Satchel
UPDATE locales_gameobject set name_loc2='Rail' where entry=80024; -- Name: Rail
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=82139; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Lamppost' where entry=82140; -- Name: Lamppost
UPDATE locales_gameobject set name_loc2='Stolen Books' where entry=83763; -- Name: Stolen Books
UPDATE locales_gameobject set name_loc2='Campfire' where entry=88498; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=91738; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=92098; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=94189; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Shaman Shrine' where entry=100028; -- Name: Shaman Shrine
UPDATE locales_gameobject set name_loc2='Shaman Shrine' where entry=100035; -- Name: Shaman Shrine
UPDATE locales_gameobject set name_loc2='Shaman Shrine' where entry=101750; -- Name: Shaman Shrine
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=111993; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=111994; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=111995; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=111996; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=111998; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=112000; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=112015; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=112023; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=112024; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=112028; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=112068; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Chair' where entry=112214; -- Name: Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=112318; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Campfire' where entry=113540; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Brazier of Everfount' where entry=113791; -- Name: Brazier of Everfount
UPDATE locales_gameobject set name_loc2='Anvil' where entry=138316; -- Name: Anvil
UPDATE locales_gameobject set name_loc2='Forge' where entry=138317; -- Name: Forge
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=138318; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Doors' where entry=138493; -- Name: Doors
UPDATE locales_gameobject set name_loc2='Fierce Blaze' where entry=140106; -- Name: Fierce Blaze
UPDATE locales_gameobject set name_loc2='Fierce Blaze' where entry=140107; -- Name: Fierce Blaze
UPDATE locales_gameobject set name_loc2='Fierce Blaze' where entry=140108; -- Name: Fierce Blaze
UPDATE locales_gameobject set name_loc2='Campfire' where entry=140211; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=140212; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=140213; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=140357; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Smoldering Coals' where entry=140358; -- Name: Smoldering Coals
UPDATE locales_gameobject set name_loc2='Smoldering Coals' where entry=140359; -- Name: Smoldering Coals
UPDATE locales_gameobject set name_loc2='Campfire' where entry=140360; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=140931; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Sun Rock Retreat' where entry=141076; -- Name: Sun Rock Retreat
UPDATE locales_gameobject set name_loc2='Greatwood Vale' where entry=141077; -- Name: Greatwood Vale
UPDATE locales_gameobject set name_loc2='The Barrens' where entry=141078; -- Name: The Barrens
UPDATE locales_gameobject set name_loc2='Anvil' where entry=141839; -- Name: Anvil
UPDATE locales_gameobject set name_loc2='Anvil' where entry=141840; -- Name: Anvil
UPDATE locales_gameobject set name_loc2='Forge' where entry=141841; -- Name: Forge
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=141843; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Cauldron' where entry=141845; -- Name: Cauldron
UPDATE locales_gameobject set name_loc2='Cannon' where entry=141860; -- Name: Cannon
UPDATE locales_gameobject set name_loc2='Cannon' where entry=141861; -- Name: Cannon
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=141971; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=142018; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=142019; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=142020; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=142021; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Rin\'ji\'s Cage' where entry=142036; -- Name: Rin\'ji\'s Cage
UPDATE locales_gameobject set name_loc2='Egg-O-Matic' where entry=142071; -- Name: Egg-O-Matic
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=142101; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Mailbox' where entry=142111; -- Name: Mailbox
UPDATE locales_gameobject set name_loc2='Mailbox' where entry=142119; -- Name: Mailbox
UPDATE locales_gameobject set name_loc2='Campfire' where entry=142196; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Bubbling Cauldron' where entry=142693; -- Name: Bubbling Cauldron
UPDATE locales_gameobject set name_loc2='Venom Bottle' where entry=142708; -- Name: Venom Bottle
UPDATE locales_gameobject set name_loc2='Venom Bottle' where entry=142709; -- Name: Venom Bottle
UPDATE locales_gameobject set name_loc2='Venom Bottle' where entry=142710; -- Name: Venom Bottle
UPDATE locales_gameobject set name_loc2='Venom Bottle' where entry=142711; -- Name: Venom Bottle
UPDATE locales_gameobject set name_loc2='Stone Chair' where entry=142947; -- Name: Stone Chair
UPDATE locales_gameobject set name_loc2='Stone Chair' where entry=142948; -- Name: Stone Chair
UPDATE locales_gameobject set name_loc2='Feralas: A History' where entry=142958; -- Name: Feralas: A History
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=142966; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Flinthammer\'s Armorer and Clothier' where entry=143332; -- Name: Flinthammer\'s Armorer and Clothier
UPDATE locales_gameobject set name_loc2='Mailbox' where entry=143987; -- Name: Mailbox
UPDATE locales_gameobject set name_loc2='Mailbox' where entry=143988; -- Name: Mailbox
UPDATE locales_gameobject set name_loc2='Mailbox' where entry=143989; -- Name: Mailbox
UPDATE locales_gameobject set name_loc2='Mailbox' where entry=143990; -- Name: Mailbox
UPDATE locales_gameobject set name_loc2='Mailbox' where entry=144570; -- Name: Mailbox
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=146088; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=146089; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=146090; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=147065; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=147078; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=147079; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=147080; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=147536; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Stolen Silver' where entry=147557; -- Name: Stolen Silver
UPDATE locales_gameobject set name_loc2='Circle of Aquementas' where entry=148507; -- Name: Circle of Aquementas
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=148890; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=148896; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=148897; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=148907; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=148908; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Ani' where entry=149420; -- Name: Ani
UPDATE locales_gameobject set name_loc2='Rune of Jin\'yael' where entry=149480; -- Name: Rune of Jin\'yael
UPDATE locales_gameobject set name_loc2='Rune of Beth\'Amara' where entry=149481; -- Name: Rune of Beth\'Amara
UPDATE locales_gameobject set name_loc2='Rune of Markri' where entry=149482; -- Name: Rune of Markri
UPDATE locales_gameobject set name_loc2='Rune of Sael\'hai' where entry=149483; -- Name: Rune of Sael\'hai
UPDATE locales_gameobject set name_loc2='Wanted Poster' where entry=150075; -- Name: Wanted Poster
UPDATE locales_gameobject set name_loc2='Campfire' where entry=150713; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Kaldorei Tome of Summoning' where entry=151286; -- Name: Kaldorei Tome of Summoning
UPDATE locales_gameobject set name_loc2='Shimmering Flats' where entry=151980; -- Name: Shimmering Flats
UPDATE locales_gameobject set name_loc2='Steamwheedle Port' where entry=151981; -- Name: Steamwheedle Port
UPDATE locales_gameobject set name_loc2='Gadgetzan' where entry=151982; -- Name: Gadgetzan
UPDATE locales_gameobject set name_loc2='auctionhouse' where entry=151992; -- Name: auctionhouse
UPDATE locales_gameobject set name_loc2='Magus Rimtori\'s Journal' where entry=152098; -- Name: Magus Rimtori\'s Journal
UPDATE locales_gameobject set name_loc2='Campfire' where entry=152324; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Kolkar\'s Booty' where entry=152608; -- Name: Kolkar\'s Booty
UPDATE locales_gameobject set name_loc2='Campfire' where entry=152619; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Darnassus Auction House' where entry=153113; -- Name: Darnassus Auction House
UPDATE locales_gameobject set name_loc2='Mailbox' where entry=153578; -- Name: Mailbox
UPDATE locales_gameobject set name_loc2='Campfire' where entry=153583; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Mailbox' where entry=163313; -- Name: Mailbox
UPDATE locales_gameobject set name_loc2='The Dead Tree' where entry=164644; -- Name: The Dead Tree
UPDATE locales_gameobject set name_loc2='Echeyakee\'s Lair' where entry=164651; -- Name: Echeyakee\'s Lair
UPDATE locales_gameobject set name_loc2='Roaring Fire' where entry=164699; -- Name: Roaring Fire
UPDATE locales_gameobject set name_loc2='Roaring Fire' where entry=164700; -- Name: Roaring Fire
UPDATE locales_gameobject set name_loc2='Roaring Fire' where entry=164701; -- Name: Roaring Fire
UPDATE locales_gameobject set name_loc2='Blazing Fire' where entry=164702; -- Name: Blazing Fire
UPDATE locales_gameobject set name_loc2='Blazing Fire' where entry=164703; -- Name: Blazing Fire
UPDATE locales_gameobject set name_loc2='Blazing Fire' where entry=164705; -- Name: Blazing Fire
UPDATE locales_gameobject set name_loc2='Zeppelin Landing Tower' where entry=165557; -- Name: Zeppelin Landing Tower
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=169286; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=170033; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Doodad_GeneralChairLoEnd27' where entry=170034; -- Name: Doodad_GeneralChairLoEnd27
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=170047; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=170053; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=170054; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=170067; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Stone Chair' where entry=171567; -- Name: Stone Chair
UPDATE locales_gameobject set name_loc2='Stone Chair' where entry=171568; -- Name: Stone Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=171619; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=171620; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=171621; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=171622; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='Dwarven High Back Chair' where entry=171648; -- Name: Dwarven High Back Chair
UPDATE locales_gameobject set name_loc2='Dwarven High Back Chair' where entry=171649; -- Name: Dwarven High Back Chair
UPDATE locales_gameobject set name_loc2='Stone Chair' where entry=171674; -- Name: Stone Chair
UPDATE locales_gameobject set name_loc2='Stone Chair' where entry=171675; -- Name: Stone Chair
UPDATE locales_gameobject set name_loc2='Stone Chair' where entry=171676; -- Name: Stone Chair
UPDATE locales_gameobject set name_loc2='Stone Chair' where entry=171677; -- Name: Stone Chair
UPDATE locales_gameobject set name_loc2='Stone Chair' where entry=171718; -- Name: Stone Chair
UPDATE locales_gameobject set name_loc2='Stone Chair' where entry=171719; -- Name: Stone Chair
UPDATE locales_gameobject set name_loc2='Stone Chair' where entry=171720; -- Name: Stone Chair
UPDATE locales_gameobject set name_loc2='Stone Chair' where entry=171721; -- Name: Stone Chair
UPDATE locales_gameobject set name_loc2='Dwarven Brazier' where entry=171757; -- Name: Dwarven Brazier
UPDATE locales_gameobject set name_loc2='Dwarven Brazier' where entry=171758; -- Name: Dwarven Brazier
UPDATE locales_gameobject set name_loc2='Dwarven Brazier' where entry=171759; -- Name: Dwarven Brazier
UPDATE locales_gameobject set name_loc2='Dwarven Brazier' where entry=171760; -- Name: Dwarven Brazier
UPDATE locales_gameobject set name_loc2='Dwarven Brazier' where entry=171761; -- Name: Dwarven Brazier
UPDATE locales_gameobject set name_loc2='Dwarven Brazier' where entry=171762; -- Name: Dwarven Brazier
UPDATE locales_gameobject set name_loc2='Dwarven Brazier' where entry=171763; -- Name: Dwarven Brazier
UPDATE locales_gameobject set name_loc2='Mighty Blaze' where entry=172943; -- Name: Mighty Blaze
UPDATE locales_gameobject set name_loc2='Mighty Blaze' where entry=172998; -- Name: Mighty Blaze
UPDATE locales_gameobject set name_loc2='Mighty Blaze' where entry=172999; -- Name: Mighty Blaze
UPDATE locales_gameobject set name_loc2='Mighty Blaze' where entry=173000; -- Name: Mighty Blaze
UPDATE locales_gameobject set name_loc2='Mighty Blaze' where entry=173001; -- Name: Mighty Blaze
UPDATE locales_gameobject set name_loc2='Mighty Blaze' where entry=173002; -- Name: Mighty Blaze
UPDATE locales_gameobject set name_loc2='Mighty Blaze' where entry=173003; -- Name: Mighty Blaze
UPDATE locales_gameobject set name_loc2='Mighty Blaze' where entry=173004; -- Name: Mighty Blaze
UPDATE locales_gameobject set name_loc2='Darkfire Enclave' where entry=173005; -- Name: Darkfire Enclave
UPDATE locales_gameobject set name_loc2='Mighty Blaze' where entry=173124; -- Name: Mighty Blaze
UPDATE locales_gameobject set name_loc2='Mighty Blaze' where entry=173126; -- Name: Mighty Blaze
UPDATE locales_gameobject set name_loc2='Mighty Blaze' where entry=173201; -- Name: Mighty Blaze
UPDATE locales_gameobject set name_loc2='AuctionNode' where entry=173227; -- Name: AuctionNode
UPDATE locales_gameobject set name_loc2='Mighty Blaze' where entry=173228; -- Name: Mighty Blaze
UPDATE locales_gameobject set name_loc2='Mighty Blaze' where entry=173229; -- Name: Mighty Blaze
UPDATE locales_gameobject set name_loc2='Mighty Blaze' where entry=173230; -- Name: Mighty Blaze
UPDATE locales_gameobject set name_loc2='Mighty Blaze' where entry=173231; -- Name: Mighty Blaze
UPDATE locales_gameobject set name_loc2='Xavian Waterfall' where entry=174797; -- Name: Xavian Waterfall
UPDATE locales_gameobject set name_loc2='Doodad_GeneralChairLoEnd75' where entry=174864; -- Name: Doodad_GeneralChairLoEnd75
UPDATE locales_gameobject set name_loc2='Doodad_GeneralChairLoEnd64' where entry=174865; -- Name: Doodad_GeneralChairLoEnd64
UPDATE locales_gameobject set name_loc2='Doodad_GeneralChairLoEnd72' where entry=174866; -- Name: Doodad_GeneralChairLoEnd72
UPDATE locales_gameobject set name_loc2='Doodad_GeneralChairLoEnd66' where entry=174867; -- Name: Doodad_GeneralChairLoEnd66
UPDATE locales_gameobject set name_loc2='Doodad_GeneralChairLoEnd76' where entry=174868; -- Name: Doodad_GeneralChairLoEnd76
UPDATE locales_gameobject set name_loc2='Doodad_GeneralChairLoEnd78' where entry=174869; -- Name: Doodad_GeneralChairLoEnd78
UPDATE locales_gameobject set name_loc2='Doodad_GeneralChairLoEnd79' where entry=174870; -- Name: Doodad_GeneralChairLoEnd79
UPDATE locales_gameobject set name_loc2='Doodad_GeneralChairLoEnd81' where entry=174871; -- Name: Doodad_GeneralChairLoEnd81
UPDATE locales_gameobject set name_loc2='Chair' where entry=174946; -- Name: Chair
UPDATE locales_gameobject set name_loc2='Wooden Chair' where entry=174968; -- Name: Wooden Chair
UPDATE locales_gameobject set name_loc2='The Sparklematic 5200' where entry=175087; -- Name: The Sparklematic 5200
UPDATE locales_gameobject set name_loc2='Beached Sea Creature' where entry=175226; -- Name: Beached Sea Creature
UPDATE locales_gameobject set name_loc2='Beached Sea Creature' where entry=175230; -- Name: Beached Sea Creature
UPDATE locales_gameobject set name_loc2='Beached Sea Creature' where entry=175233; -- Name: Beached Sea Creature
UPDATE locales_gameobject set name_loc2='WANTED: Murkdeep!' where entry=175320; -- Name: WANTED: Murkdeep!
UPDATE locales_gameobject set name_loc2='Blackwood Nut Stores' where entry=175329; -- Name: Blackwood Nut Stores
UPDATE locales_gameobject set name_loc2='Blackwood Fruit Stores' where entry=175330; -- Name: Blackwood Fruit Stores
UPDATE locales_gameobject set name_loc2='Blackwood Grain Stores' where entry=175331; -- Name: Blackwood Grain Stores
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=175406; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Blazing Fire' where entry=175591; -- Name: Blazing Fire
UPDATE locales_gameobject set name_loc2='Cooking Fire' where entry=175592; -- Name: Cooking Fire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=175593; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=175594; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=175595; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Small Fire' where entry=175596; -- Name: Small Fire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=175597; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=175598; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Raging Fire' where entry=175599; -- Name: Raging Fire
UPDATE locales_gameobject set name_loc2='Cooking Fire' where entry=175600; -- Name: Cooking Fire
UPDATE locales_gameobject set name_loc2='Small Fire' where entry=175601; -- Name: Small Fire
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=175602; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=175603; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Cooking Fire' where entry=175604; -- Name: Cooking Fire
UPDATE locales_gameobject set name_loc2='Cooking Fire' where entry=175605; -- Name: Cooking Fire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=175630; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=175631; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=175632; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Doodad_RuinedSign02' where entry=175644; -- Name: Doodad_RuinedSign02
UPDATE locales_gameobject set name_loc2='Doodad_RuinedSign03' where entry=175645; -- Name: Doodad_RuinedSign03
UPDATE locales_gameobject set name_loc2='Doodad_RuinedSign05' where entry=175646; -- Name: Doodad_RuinedSign05
UPDATE locales_gameobject set name_loc2='Doodad_WoodSignPointerNice03' where entry=175647; -- Name: Doodad_WoodSignPointerNice03
UPDATE locales_gameobject set name_loc2='Doodad_WoodSignPointerNice05' where entry=175648; -- Name: Doodad_WoodSignPointerNice05
UPDATE locales_gameobject set name_loc2='Doodad_WoodSignPointerNice04' where entry=175649; -- Name: Doodad_WoodSignPointerNice04
UPDATE locales_gameobject set name_loc2='Doodad_WoodSignPointerNice06' where entry=175650; -- Name: Doodad_WoodSignPointerNice06
UPDATE locales_gameobject set name_loc2='Doodad_WoodSignPointerNice07' where entry=175651; -- Name: Doodad_WoodSignPointerNice07
UPDATE locales_gameobject set name_loc2='Doodad_WoodSignPointerNice08' where entry=175652; -- Name: Doodad_WoodSignPointerNice08
UPDATE locales_gameobject set name_loc2='Doodad_WoodSignPointerNice09' where entry=175653; -- Name: Doodad_WoodSignPointerNice09
UPDATE locales_gameobject set name_loc2='Doodad_RuinedSign06' where entry=175654; -- Name: Doodad_RuinedSign06
UPDATE locales_gameobject set name_loc2='Doodad_RuinedSign07' where entry=175655; -- Name: Doodad_RuinedSign07
UPDATE locales_gameobject set name_loc2='Doodad_WoodSignPointerNice10' where entry=175656; -- Name: Doodad_WoodSignPointerNice10
UPDATE locales_gameobject set name_loc2='Doodad_WoodSignPointerNice11' where entry=175657; -- Name: Doodad_WoodSignPointerNice11
UPDATE locales_gameobject set name_loc2='Doodad_GnomeSign_Engineer01' where entry=175663; -- Name: Doodad_GnomeSign_Engineer01
UPDATE locales_gameobject set name_loc2='Doodad_DwarfSign_Alchemist01' where entry=175664; -- Name: Doodad_DwarfSign_Alchemist01
UPDATE locales_gameobject set name_loc2='Doodad_DwarfSign_Fireworks01' where entry=175665; -- Name: Doodad_DwarfSign_Fireworks01
UPDATE locales_gameobject set name_loc2='Brazier' where entry=175666; -- Name: Brazier
UPDATE locales_gameobject set name_loc2='Brazier' where entry=175667; -- Name: Brazier
UPDATE locales_gameobject set name_loc2='Postbox' where entry=175668; -- Name: Postbox
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=175671; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=175672; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Raging Fire' where entry=175674; -- Name: Raging Fire
UPDATE locales_gameobject set name_loc2='Anvil' where entry=175677; -- Name: Anvil
UPDATE locales_gameobject set name_loc2='Forge' where entry=175678; -- Name: Forge
UPDATE locales_gameobject set name_loc2='Mailbox' where entry=175864; -- Name: Mailbox
UPDATE locales_gameobject set name_loc2='Gadgetzan Auction' where entry=175904; -- Name: Gadgetzan Auction
UPDATE locales_gameobject set name_loc2='Booty Bay Alarm Bell' where entry=175948; -- Name: Booty Bay Alarm Bell
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176004; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176005; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176006; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176007; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176008; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176009; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176010; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176011; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176012; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176013; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176014; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176015; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176016; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176017; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176018; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176019; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176020; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176021; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176022; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176023; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176024; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176025; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176026; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176027; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176028; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176029; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176030; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176031; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176032; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176033; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176034; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176035; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176036; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176037; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176038; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176039; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176040; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176041; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176042; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176043; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176044; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176045; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176046; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176047; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176048; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176049; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176050; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176051; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176052; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176053; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176054; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176055; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176056; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176057; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176058; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176059; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176060; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176061; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176062; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176063; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176064; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176065; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176066; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176067; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176068; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176069; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176070; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176071; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176072; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176073; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176074; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176075; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176076; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176077; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176078; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176079; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway' where entry=176080; -- Name: Subway
UPDATE locales_gameobject set name_loc2='Subway' where entry=176081; -- Name: Subway
UPDATE locales_gameobject set name_loc2='Subway' where entry=176082; -- Name: Subway
UPDATE locales_gameobject set name_loc2='Subway' where entry=176083; -- Name: Subway
UPDATE locales_gameobject set name_loc2='Subway' where entry=176084; -- Name: Subway
UPDATE locales_gameobject set name_loc2='Subway' where entry=176085; -- Name: Subway
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176098; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176099; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176100; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176101; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176102; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176103; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176104; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176105; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176106; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176107; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176108; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Subway Bench' where entry=176109; -- Name: Subway Bench
UPDATE locales_gameobject set name_loc2='Brazier' where entry=176113; -- Name: Brazier
UPDATE locales_gameobject set name_loc2='Beached Sea Turtle' where entry=176191; -- Name: Beached Sea Turtle
UPDATE locales_gameobject set name_loc2='Beached Sea Turtle' where entry=176197; -- Name: Beached Sea Turtle
UPDATE locales_gameobject set name_loc2='Beached Sea Turtle' where entry=176198; -- Name: Beached Sea Turtle
UPDATE locales_gameobject set name_loc2='Campfire' where entry=176200; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=176204; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Command Tent' where entry=176210; -- Name: Command Tent
UPDATE locales_gameobject set name_loc2='Campfire' where entry=176265; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=176282; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=176290; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=176292; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=176293; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=176294; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Scourge Cauldron' where entry=176361; -- Name: Scourge Cauldron
UPDATE locales_gameobject set name_loc2='Boat to Menethil' where entry=176364; -- Name: Boat to Menethil
UPDATE locales_gameobject set name_loc2='Boat to Teldrassil' where entry=176365; -- Name: Boat to Teldrassil
UPDATE locales_gameobject set name_loc2='Boat to Theramore' where entry=176369; -- Name: Boat to Theramore
UPDATE locales_gameobject set name_loc2='Boat to Auberdine' where entry=176370; -- Name: Boat to Auberdine
UPDATE locales_gameobject set name_loc2='Scourge Cauldron' where entry=176393; -- Name: Scourge Cauldron
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=176505; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Door' where entry=176632; -- Name: Door
UPDATE locales_gameobject set name_loc2='Arthas\' Tears' where entry=176642; -- Name: Arthas\' Tears
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=176705; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=176786; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Campfire' where entry=176791; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Brazier' where entry=176885; -- Name: Brazier
UPDATE locales_gameobject set name_loc2='Brazier' where entry=176886; -- Name: Brazier
UPDATE locales_gameobject set name_loc2='Brazier' where entry=176887; -- Name: Brazier
UPDATE locales_gameobject set name_loc2='Brazier' where entry=176888; -- Name: Brazier
UPDATE locales_gameobject set name_loc2='Brazier' where entry=176889; -- Name: Brazier
UPDATE locales_gameobject set name_loc2='Brazier' where entry=176890; -- Name: Brazier
UPDATE locales_gameobject set name_loc2='Brazier' where entry=176891; -- Name: Brazier
UPDATE locales_gameobject set name_loc2='Brazier' where entry=176892; -- Name: Brazier
UPDATE locales_gameobject set name_loc2='Campfire' where entry=176904; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='CavernDoor01' where entry=176996; -- Name: CavernDoor01
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=177084; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Ahn\'Qiraj Gong' where entry=177223; -- Name: Ahn\'Qiraj Gong
UPDATE locales_gameobject set name_loc2='Vault Door' where entry=177237; -- Name: Vault Door
UPDATE locales_gameobject set name_loc2='Vault Door' where entry=177238; -- Name: Vault Door
UPDATE locales_gameobject set name_loc2='Cauldron' where entry=177244; -- Name: Cauldron
UPDATE locales_gameobject set name_loc2='Moonwell' where entry=177274; -- Name: Moonwell
UPDATE locales_gameobject set name_loc2='Scourge Cauldron' where entry=177289; -- Name: Scourge Cauldron
UPDATE locales_gameobject set name_loc2='Brazier' where entry=177290; -- Name: Brazier
UPDATE locales_gameobject set name_loc2='Brazier' where entry=177291; -- Name: Brazier
UPDATE locales_gameobject set name_loc2='Chair' where entry=177364; -- Name: Chair
UPDATE locales_gameobject set name_loc2='Campfire' where entry=177424; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Maraudon Portal' where entry=178400; -- Name: Maraudon Portal
UPDATE locales_gameobject set name_loc2='Steamsaw' where entry=178664; -- Name: Steamsaw
UPDATE locales_gameobject set name_loc2='Steamsaw' where entry=178665; -- Name: Steamsaw
UPDATE locales_gameobject set name_loc2='Campfire' where entry=179147; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Meeting Stone' where entry=179586; -- Name: Meeting Stone
UPDATE locales_gameobject set name_loc2='Meeting Stone' where entry=179587; -- Name: Meeting Stone
UPDATE locales_gameobject set name_loc2='CavernDoor01' where entry=179588; -- Name: CavernDoor01
UPDATE locales_gameobject set name_loc2='Meetingstone01' where entry=179597; -- Name: Meetingstone01
UPDATE locales_gameobject set name_loc2='Brazier' where entry=179682; -- Name: Brazier
UPDATE locales_gameobject set name_loc2='Campfire' where entry=179846; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Forge' where entry=179924; -- Name: Forge
UPDATE locales_gameobject set name_loc2='OUT OF ORDER! Use Postman instead - your GM\'s' where entry=179963; -- Name: OUT OF ORDER! Use Postman instead - your GM\'s
UPDATE locales_gameobject set name_loc2='Mysterious Wailing Caverns Chest' where entry=180055; -- Name: Mysterious Wailing Caverns Chest
UPDATE locales_gameobject set name_loc2='Doodad_SmallBrazierNoOmni20' where entry=180245; -- Name: Doodad_SmallBrazierNoOmni20
UPDATE locales_gameobject set name_loc2='Gates of Zul\'Gurub' where entry=180323; -- Name: Gates of Zul\'Gurub
UPDATE locales_gameobject set name_loc2='Altar of Zanza' where entry=180367; -- Name: Altar of Zanza
UPDATE locales_gameobject set name_loc2='Gong of Bethekk' where entry=180526; -- Name: Gong of Bethekk
UPDATE locales_gameobject set name_loc2='Cooking Brazier' where entry=180688; -- Name: Cooking Brazier
UPDATE locales_gameobject set name_loc2='Cooking Brazier' where entry=180689; -- Name: Cooking Brazier
UPDATE locales_gameobject set name_loc2='Arena Spoils' where entry=181074; -- Name: Arena Spoils
UPDATE locales_gameobject set name_loc2='Campfire' where entry=181099; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Ancient Door' where entry=181137; -- Name: Ancient Door
UPDATE locales_gameobject set name_loc2='Grand Widow Faerlina Door' where entry=181167; -- Name: Grand Widow Faerlina Door
UPDATE locales_gameobject set name_loc2='Portal' where entry=181229; -- Name: Portal
UPDATE locales_gameobject set name_loc2='Anvil' where entry=181596; -- Name: Anvil
UPDATE locales_gameobject set name_loc2='Mailbox' where entry=181639; -- Name: Mailbox
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=184161; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Doodad_BlackRockCellDoor01' where entry=184247; -- Name: Doodad_BlackRockCellDoor01
UPDATE locales_gameobject set name_loc2='Cooking Fire' where entry=184618; -- Name: Cooking Fire
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=184648; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=184649; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=184650; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=184651; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Chair' where entry=184733; -- Name: Chair
UPDATE locales_gameobject set name_loc2='Campfire' where entry=184818; -- Name: Campfire
UPDATE locales_gameobject set name_loc2='Sealed Tome' where entry=184847; -- Name: Sealed Tome
UPDATE locales_gameobject set name_loc2='Meeting Stone' where entry=185433; -- Name: Meeting Stone
UPDATE locales_gameobject set name_loc2='Bonfire' where entry=186132; -- Name: Bonfire
UPDATE locales_gameobject set name_loc2='Bench' where entry=186898; -- Name: Bench
UPDATE locales_gameobject set name_loc2='Mailbox' where entry=187260; -- Name: Mailbox
UPDATE locales_gameobject set name_loc2='Cannon' where entry=193011; -- Name: Cannon
UPDATE locales_gameobject set name_loc2='Fel Orc Encampment Custom Area' where entry=200000; -- Name: Fel Orc Encampment Custom Area
UPDATE locales_gameobject set name_loc2='Shopping Centre' where entry=200001; -- Name: Shopping Centre
UPDATE locales_gameobject set name_loc2='New Year Alliance Hanging Banner' where entry=210210; -- Name: New Year Alliance Hanging Banner
UPDATE locales_gameobject set name_loc2='New Year Alliance Hanging Banner 02' where entry=210211; -- Name: New Year Alliance Hanging Banner 02
UPDATE locales_gameobject set name_loc2='New Year Horde Hanging Banner' where entry=210212; -- Name: New Year Horde Hanging Banner
UPDATE locales_gameobject set name_loc2='New Year Horde Hanging Banner 02' where entry=210213; -- Name: New Year Horde Hanging Banner 02
UPDATE locales_gameobject set name_loc2='New Year Alliance Standing Banner' where entry=210214; -- Name: New Year Alliance Standing Banner
UPDATE locales_gameobject set name_loc2='New Year Horde Standing Banner' where entry=210215; -- Name: New Year Horde Standing Banner
UPDATE locales_gameobject set name_loc2='Excavation Tent Pavillion' where entry=210286; -- Name: Excavation Tent Pavillion
UPDATE locales_gameobject set name_loc2='Ahn\'Qiraj Ossirian Crystal' where entry=210312; -- Name: Ahn\'Qiraj Ossirian Crystal
UPDATE locales_gameobject set name_loc2='Ahn\'Qiraj Ossirian Crystal' where entry=210313; -- Name: Ahn\'Qiraj Ossirian Crystal
UPDATE locales_gameobject set name_loc2='Communication Crystal' where entry=210327; -- Name: Communication Crystal
UPDATE locales_gameobject set name_loc2='Communication Crystal' where entry=210328; -- Name: Communication Crystal
UPDATE locales_gameobject set name_loc2='Communication Crystal' where entry=210329; -- Name: Communication Crystal
UPDATE locales_gameobject set name_loc2='Communication Crystal' where entry=210330; -- Name: Communication Crystal
UPDATE locales_gameobject set name_loc2='Communication Crystal' where entry=210331; -- Name: Communication Crystal
UPDATE locales_gameobject set name_loc2='Communication Crystal' where entry=210332; -- Name: Communication Crystal
UPDATE locales_gameobject set name_loc2='Ahn\'Qiraj Gong' where entry=210334; -- Name: Ahn\'Qiraj Gong
UPDATE locales_gameobject set name_loc2='Twilight Tablet' where entry=210335; -- Name: Twilight Tablet
UPDATE locales_gameobject set name_loc2='Twilight Tablet' where entry=210336; -- Name: Twilight Tablet
UPDATE locales_gameobject set name_loc2='Glyphed Crystal' where entry=210337; -- Name: Glyphed Crystal
UPDATE locales_gameobject set name_loc2='Gorishi Silithid Crystal' where entry=210338; -- Name: Gorishi Silithid Crystal
UPDATE locales_gameobject set name_loc2='Ahn\'Qiraj Sand Trap' where entry=210339; -- Name: Ahn\'Qiraj Sand Trap
UPDATE locales_gameobject set name_loc2='Hive Fireflies 01' where entry=210341; -- Name: Hive Fireflies 01
UPDATE locales_gameobject set name_loc2='Glyphed Crystal' where entry=210342; -- Name: Glyphed Crystal
UPDATE locales_gameobject set name_loc2='Sand Worm Rock Base' where entry=210343; -- Name: Sand Worm Rock Base
UPDATE locales_gameobject set name_loc2='Silithus Crystal Formation 03' where entry=210344; -- Name: Silithus Crystal Formation 03
UPDATE locales_gameobject set name_loc2='Floating Red Crystal Broken 03' where entry=210345; -- Name: Floating Red Crystal Broken 03
UPDATE locales_gameobject set name_loc2='Floating Red Crystal Broken 01' where entry=210346; -- Name: Floating Red Crystal Broken 01
UPDATE locales_gameobject set name_loc2='Ahn\'Qiraj Door 01' where entry=210347; -- Name: Ahn\'Qiraj Door 01
UPDATE locales_gameobject set name_loc2='Floating Purple Crystal Broken 01' where entry=210348; -- Name: Floating Purple Crystal Broken 01
UPDATE locales_gameobject set name_loc2='Gastric Exit' where entry=210349; -- Name: Gastric Exit
UPDATE locales_gameobject set name_loc2='Anvil' where entry=211016; -- Name: Anvil
UPDATE locales_gameobject set name_loc2='Kre\'tal\'s Wagon' where entry=211017; -- Name: Kre\'tal\'s Wagon
UPDATE locales_gameobject set name_loc2='Asheron\'s Tome of Summoning' where entry=211018; -- Name: Asheron\'s Tome of Summoning
UPDATE locales_gameobject set name_loc2='Altar of Hyjal' where entry=211019; -- Name: Altar of Hyjal
UPDATE locales_gameobject set name_loc2='Summoning Circle' where entry=211020; -- Name: Summoning Circle
UPDATE locales_gameobject set name_loc2='Eye of Asheron' where entry=211021; -- Name: Eye of Asheron
UPDATE locales_gameobject set name_loc2='Commander\'s Tent' where entry=211022; -- Name: Commander\'s Tent
UPDATE locales_gameobject set name_loc2='Black Portal' where entry=211023; -- Name: Black Portal
UPDATE locales_gameobject set name_loc2='Black Portal' where entry=211024; -- Name: Black Portal
UPDATE locales_gameobject set name_loc2='Banner' where entry=211029; -- Name: Banner
UPDATE locales_gameobject set name_loc2='Gold Mine' where entry=211032; -- Name: Gold Mine
UPDATE locales_gameobject set name_loc2='Aura' where entry=211033; -- Name: Aura
UPDATE locales_gameobject set name_loc2='Aura' where entry=211034; -- Name: Aura
UPDATE locales_gameobject set name_loc2='Lair Exit' where entry=211035; -- Name: Lair Exit
UPDATE locales_gameobject set name_loc2='Fire Totem' where entry=211036; -- Name: Fire Totem
UPDATE locales_gameobject set name_loc2='Teleport-Stone to Hyjal' where entry=211050; -- Name: Teleport-Stone to Hyjal
UPDATE locales_gameobject set name_loc2='Mysterious Tree Stump' where entry=211051; -- Name: Mysterious Tree Stump
UPDATE locales_gameobject set name_loc2='Tree Stump' where entry=211052; -- Name: Tree Stump
UPDATE locales_gameobject set name_loc2='Mysterious Monument' where entry=211053; -- Name: Mysterious Monument
UPDATE locales_gameobject set name_loc2='Lava Crack' where entry=211054; -- Name: Lava Crack
UPDATE locales_gameobject set name_loc2='Elwynn Fence' where entry=211062; -- Name: Elwynn Fence
UPDATE locales_gameobject set name_loc2='Elwynn Fence' where entry=211063; -- Name: Elwynn Fence
UPDATE locales_gameobject set name_loc2='Rockwall Fence' where entry=211064; -- Name: Rockwall Fence
UPDATE locales_gameobject set name_loc2='Grave' where entry=211065; -- Name: Grave
UPDATE locales_gameobject set name_loc2='Sarcophag' where entry=211067; -- Name: Sarcophag
UPDATE locales_gameobject set name_loc2='Fire Totem' where entry=211068; -- Name: Fire Totem
UPDATE locales_gameobject set name_loc2='Mephistroph\'s HellFire' where entry=211084; -- Name: Mephistroph\'s HellFire
UPDATE locales_gameobject set name_loc2='TEMP Machine Shop' where entry=300010; -- Name: TEMP Machine Shop
UPDATE locales_gameobject set name_loc2='Nearby Tubers' where entry=300011; -- Name: Nearby Tubers
UPDATE locales_gameobject set name_loc2='TEMP Stone of Outer Binding' where entry=300012; -- Name: TEMP Stone of Outer Binding
UPDATE locales_gameobject set name_loc2='TEMP Mana Rift Disturbance' where entry=300013; -- Name: TEMP Mana Rift Disturbance
UPDATE locales_gameobject set name_loc2='TEMP Water Purity - Silverpine' where entry=300014; -- Name: TEMP Water Purity - Silverpine
UPDATE locales_gameobject set name_loc2='TEMP Pirate Ship Bilge' where entry=300015; -- Name: TEMP Pirate Ship Bilge
UPDATE locales_gameobject set name_loc2='TEMP Witherbark Village' where entry=300016; -- Name: TEMP Witherbark Village
UPDATE locales_gameobject set name_loc2='TEMP Shadra\'Alor Altar' where entry=300017; -- Name: TEMP Shadra\'Alor Altar
UPDATE locales_gameobject set name_loc2='TEMP Hatetalon Stones' where entry=300018; -- Name: TEMP Hatetalon Stones
UPDATE locales_gameobject set name_loc2='TEMP Sanctum of the Fallen God' where entry=300019; -- Name: TEMP Sanctum of the Fallen God
UPDATE locales_gameobject set name_loc2='TEMP Miblon Snarltooth' where entry=300020; -- Name: TEMP Miblon Snarltooth
UPDATE locales_gameobject set name_loc2='TEMP Gadgetzan Graveyard' where entry=300021; -- Name: TEMP Gadgetzan Graveyard
UPDATE locales_gameobject set name_loc2='TEMP the ruins of Irontree Woods' where entry=300022; -- Name: TEMP the ruins of Irontree Woods
UPDATE locales_gameobject set name_loc2='TEMP Golakka Crater' where entry=300023; -- Name: TEMP Golakka Crater
UPDATE locales_gameobject set name_loc2='TEMP NIU Tomb of the Seven' where entry=300024; -- Name: TEMP NIU Tomb of the Seven
UPDATE locales_gameobject set name_loc2='TEMP Corrupted Moonwell' where entry=300025; -- Name: TEMP Corrupted Moonwell
UPDATE locales_gameobject set name_loc2='TEMP Blackwood Furbolg North Bonfire' where entry=300026; -- Name: TEMP Blackwood Furbolg North Bonfire
UPDATE locales_gameobject set name_loc2='TEMP Stone of Shy-Rotam' where entry=300027; -- Name: TEMP Stone of Shy-Rotam
UPDATE locales_gameobject set name_loc2='TEMP Sacred Fire of Life' where entry=300028; -- Name: TEMP Sacred Fire of Life
UPDATE locales_gameobject set name_loc2='TEMP Scarlet Crusade Forward Camp' where entry=300029; -- Name: TEMP Scarlet Crusade Forward Camp
UPDATE locales_gameobject set name_loc2='TEMP Andorhal Tower' where entry=300030; -- Name: TEMP Andorhal Tower
UPDATE locales_gameobject set name_loc2='TEMP Scholomance Viewing Room' where entry=300031; -- Name: TEMP Scholomance Viewing Room
UPDATE locales_gameobject set name_loc2='TEMP Umi\'s Friend' where entry=300032; -- Name: TEMP Umi\'s Friend
UPDATE locales_gameobject set name_loc2='TEMP the crate in the center of the Northridge Lumber Mill' where entry=300033; -- Name: TEMP the crate in the center of the Northridge Lumber Mill
UPDATE locales_gameobject set name_loc2='TEMP Darrowshire Town Square' where entry=300034; -- Name: TEMP Darrowshire Town Square
UPDATE locales_gameobject set name_loc2='TEMP NIU Bright Light Beam' where entry=300035; -- Name: TEMP NIU Bright Light Beam
UPDATE locales_gameobject set name_loc2='TEMP The Dead Goliaths' where entry=300036; -- Name: TEMP The Dead Goliaths
UPDATE locales_gameobject set name_loc2='TEMP Maraudon Portal' where entry=300037; -- Name: TEMP Maraudon Portal
UPDATE locales_gameobject set name_loc2='TEMP NIU Horde Globe of Scrying' where entry=300038; -- Name: TEMP NIU Horde Globe of Scrying
UPDATE locales_gameobject set name_loc2='TEMP Eastern Crater' where entry=300039; -- Name: TEMP Eastern Crater
UPDATE locales_gameobject set name_loc2='TEMP Western Crater' where entry=300040; -- Name: TEMP Western Crater
UPDATE locales_gameobject set name_loc2='TEMP Snowfall Graveyard' where entry=300041; -- Name: TEMP Snowfall Graveyard
UPDATE locales_gameobject set name_loc2='TEMP Alliance Globe of Scrying' where entry=300042; -- Name: TEMP Alliance Globe of Scrying
UPDATE locales_gameobject set name_loc2='TEMP Dun Baldar Courtyard' where entry=300043; -- Name: TEMP Dun Baldar Courtyard
UPDATE locales_gameobject set name_loc2='TEMP Frostwolf Keep Courtyard' where entry=300044; -- Name: TEMP Frostwolf Keep Courtyard
UPDATE locales_gameobject set name_loc2='TEMP Snowfall Graveyard' where entry=300045; -- Name: TEMP Snowfall Graveyard
UPDATE locales_gameobject set name_loc2='TEMP East Crater' where entry=300046; -- Name: TEMP East Crater
UPDATE locales_gameobject set name_loc2='TEMP West Crater' where entry=300047; -- Name: TEMP West Crater
UPDATE locales_gameobject set name_loc2='TEMP Orange Crystal Pool' where entry=300048; -- Name: TEMP Orange Crystal Pool
UPDATE locales_gameobject set name_loc2='TEMP Kroshius\' Remains' where entry=300049; -- Name: TEMP Kroshius\' Remains
UPDATE locales_gameobject set name_loc2='TEMP Pedestal of Immol\'thar' where entry=300050; -- Name: TEMP Pedestal of Immol\'thar
UPDATE locales_gameobject set name_loc2='TEMP Circle of Dark Summoning' where entry=300051; -- Name: TEMP Circle of Dark Summoning
UPDATE locales_gameobject set name_loc2='TEMP Pagle\'s Pointe' where entry=300052; -- Name: TEMP Pagle\'s Pointe
UPDATE locales_gameobject set name_loc2='TEMP Altar of Zanza' where entry=300053; -- Name: TEMP Altar of Zanza
UPDATE locales_gameobject set name_loc2='TEMP Southshore' where entry=300054; -- Name: TEMP Southshore
UPDATE locales_gameobject set name_loc2='TEMP Bones of Grakkarond' where entry=300055; -- Name: TEMP Bones of Grakkarond
UPDATE locales_gameobject set name_loc2='TEMP Forsaken Stink Bomb' where entry=300056; -- Name: TEMP Forsaken Stink Bomb
UPDATE locales_gameobject set name_loc2='TEMP Swirling Maelstrom' where entry=300057; -- Name: TEMP Swirling Maelstrom
UPDATE locales_gameobject set name_loc2='TEMP Greater Moonlight' where entry=300058; -- Name: TEMP Greater Moonlight
UPDATE locales_gameobject set name_loc2='TEMP Voone\'s Chamber' where entry=300059; -- Name: TEMP Voone\'s Chamber
UPDATE locales_gameobject set name_loc2='TEMP Alzzin\'s Chamber' where entry=300060; -- Name: TEMP Alzzin\'s Chamber
UPDATE locales_gameobject set name_loc2='TEMP The Crimson Throne' where entry=300061; -- Name: TEMP The Crimson Throne
UPDATE locales_gameobject set name_loc2='TEMP Ras Frostwhisper\'s Chamber' where entry=300062; -- Name: TEMP Ras Frostwhisper\'s Chamber
UPDATE locales_gameobject set name_loc2='TEMP The Beast\'s Chamber' where entry=300063; -- Name: TEMP The Beast\'s Chamber
UPDATE locales_gameobject set name_loc2='TEMP Haunted Locus' where entry=300064; -- Name: TEMP Haunted Locus
UPDATE locales_gameobject set name_loc2='TEMP Blackrock Depths Arena' where entry=300065; -- Name: TEMP Blackrock Depths Arena
UPDATE locales_gameobject set name_loc2='TEMP [PH] Crystal Corpse' where entry=300066; -- Name: TEMP [PH] Crystal Corpse
UPDATE locales_gameobject set name_loc2='TEMP Midsummer Bonfire' where entry=300068; -- Name: TEMP Midsummer Bonfire
UPDATE locales_gameobject set name_loc2='TEMP Underground Water Source' where entry=300078; -- Name: TEMP Underground Water Source
UPDATE locales_gameobject set name_loc2='TEMP Un\'Goro Flat Rock' where entry=300119; -- Name: TEMP Un\'Goro Flat Rock
UPDATE locales_gameobject set name_loc2='TEMP Foulweald Totem Mound' where entry=300131; -- Name: TEMP Foulweald Totem Mound
UPDATE locales_gameobject set name_loc2='TEMP Cliffspring River Waterfall' where entry=300132; -- Name: TEMP Cliffspring River Waterfall
UPDATE locales_gameobject set name_loc2='TEMP First Tide Pool' where entry=300133; -- Name: TEMP First Tide Pool
UPDATE locales_gameobject set name_loc2='TEMP Second Tide Pool' where entry=300134; -- Name: TEMP Second Tide Pool
UPDATE locales_gameobject set name_loc2='TEMP Third Tide Pool' where entry=300135; -- Name: TEMP Third Tide Pool
UPDATE locales_gameobject set name_loc2='TEMP Fourth Tide Pool' where entry=300136; -- Name: TEMP Fourth Tide Pool
UPDATE locales_gameobject set name_loc2='TEMP Jintha\'Alor Altar' where entry=300137; -- Name: TEMP Jintha\'Alor Altar
UPDATE locales_gameobject set name_loc2='TEMP Equinex Monolith' where entry=300138; -- Name: TEMP Equinex Monolith
UPDATE locales_gameobject set name_loc2='TEMP Shards of Myzrael' where entry=300139; -- Name: TEMP Shards of Myzrael
UPDATE locales_gameobject set name_loc2='TEMP Grom\'s Monument' where entry=300140; -- Name: TEMP Grom\'s Monument
UPDATE locales_gameobject set name_loc2='TEMP High Chief Winterfall\'s Cave' where entry=300141; -- Name: TEMP High Chief Winterfall\'s Cave
UPDATE locales_gameobject set name_loc2='TEMP Shrine of Remulos' where entry=300142; -- Name: TEMP Shrine of Remulos
UPDATE locales_gameobject set name_loc2='TEMP Swamplight Manor Dock' where entry=300143; -- Name: TEMP Swamplight Manor Dock
UPDATE locales_gameobject set name_loc2='TEMP The Great Ossuary' where entry=300144; -- Name: TEMP The Great Ossuary
UPDATE locales_gameobject set name_loc2='TEMP Uther\'s Tomb Statue' where entry=300145; -- Name: TEMP Uther\'s Tomb Statue
UPDATE locales_gameobject set name_loc2='TEMP Quilboar Watering Hole' where entry=300146; -- Name: TEMP Quilboar Watering Hole
UPDATE locales_gameobject set name_loc2='TEMP Spring Well' where entry=300147; -- Name: TEMP Spring Well
UPDATE locales_gameobject set name_loc2='TEMP Ruins of Stardust Fountain' where entry=300148; -- Name: TEMP Ruins of Stardust Fountain
UPDATE locales_gameobject set name_loc2='TEMP Blackhoof Village Windmill' where entry=300149; -- Name: TEMP Blackhoof Village Windmill
UPDATE locales_gameobject set name_loc2='TEMP Grimtotem Tent' where entry=300150; -- Name: TEMP Grimtotem Tent
UPDATE locales_gameobject set name_loc2='TEMP Hyjal Family Monument' where entry=300151; -- Name: TEMP Hyjal Family Monument
UPDATE locales_gameobject set name_loc2='TEMP Entrance to Onyxia\'s Lair' where entry=300153; -- Name: TEMP Entrance to Onyxia\'s Lair
